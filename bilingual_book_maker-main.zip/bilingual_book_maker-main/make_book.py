from book_maker.cli import main

if __name__ == "__main__":
    main()
